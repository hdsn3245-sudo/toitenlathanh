# THREADS - Website bán quần áo (PHP + MySQL)

## Yêu cầu
- PHP 8.0+ (PDO MySQL bật), MySQL 5.7+/MariaDB 10.4+
- Apache (có thể dùng XAMPP)

## Cài đặt trên XAMPP
1. Giải nén thư mục `shop_quan_ao` vào `C:\xampp\htdocs\`.
2. Mở XAMPP Control Panel, bật Apache và MySQL.
3. Mở `http://localhost/phpmyadmin`, chọn Import và nhập file `database.sql`.
4. Nếu tài khoản MySQL khác mặc định, sửa `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS` trong `config.php`.
5. Mở `http://localhost/shop_quan_ao/`.

## Tài khoản quản trị demo
- Tên đăng nhập: `admin`
- Mật khẩu: `Admin@12345`
- Đăng nhập tại `http://localhost/shop_quan_ao/admin_login.php`

## Chức năng
- Danh sách sản phẩm, tìm kiếm, lọc theo danh mục, trang chi tiết.
- Giỏ hàng lưu bằng session; cập nhật/xóa sản phẩm.
- Đặt hàng, lưu khách hàng và chi tiết đơn vào MySQL; trừ tồn kho trong transaction.
- Tra cứu đơn hàng bằng mã đơn + số điện thoại.
- Trang quản trị: thêm/sửa sản phẩm, xem đơn, cập nhật trạng thái.

## Cấu trúc Database
- `admins`: tài khoản quản trị.
- `products`: sản phẩm, giá, tồn kho, ảnh, trạng thái.
- `orders`: thông tin khách và đơn hàng.
- `order_items`: các dòng sản phẩm của từng đơn.

## Lưu ý trước khi đưa lên Internet
Đây là bản nền tảng học tập/demo. Trước khi vận hành thật cần đổi mật khẩu admin, dùng HTTPS, đặt mật khẩu MySQL riêng, thêm CSRF protection, giới hạn upload/ảnh, xác thực và kiểm tra bảo mật, cấu hình sao lưu. Mật khẩu demo chỉ dùng để thử nghiệm.
