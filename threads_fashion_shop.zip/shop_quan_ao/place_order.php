<?php
require_once 'config.php';
if($_SERVER['REQUEST_METHOD']!=='POST'||empty($_SESSION['cart'])){header('Location:index.php');exit;}
$name=trim($_POST['customer_name']??'');$phone=trim($_POST['phone']??'');$address=trim($_POST['address']??'');
if($name===''||$phone===''||$address===''){die('Vui lòng nhập đủ thông tin bắt buộc.');}
try{$pdo->beginTransaction();$total=0;$lines=[];
 foreach($_SESSION['cart'] as $item){$s=$pdo->prepare("SELECT * FROM products WHERE id=? AND is_active=1 FOR UPDATE");$s->execute([$item['product_id']]);$p=$s->fetch();if(!$p||$p['stock']<(int)$item['qty'])throw new Exception('Sản phẩm '.$item['name'].' không đủ tồn kho.');$total+=$p['price']*$item['qty'];$lines[]=[$p,$item];}
 $code='TH'.date('ymd').strtoupper(bin2hex(random_bytes(3)));
 $s=$pdo->prepare("INSERT INTO orders(order_code,customer_name,phone,email,address,note,total,payment_method,status) VALUES(?,?,?,?,?,?,?,?, 'pending')");
 $s->execute([$code,$name,$phone,$_POST['email']??null,$address,$_POST['note']??null,$total,$_POST['payment_method']??'COD']);$oid=$pdo->lastInsertId();
 foreach($lines as [$p,$item]){$s=$pdo->prepare("INSERT INTO order_items(order_id,product_id,product_name,unit_price,quantity,size,color) VALUES(?,?,?,?,?,?,?)");$s->execute([$oid,$p['id'],$p['name'],$p['price'],$item['qty'],$item['size'],$item['color']]);$u=$pdo->prepare("UPDATE products SET stock=stock-? WHERE id=?");$u->execute([$item['qty'],$p['id']]);}
 $pdo->commit();unset($_SESSION['cart']);$_SESSION['last_order']=$code;header('Location:order_success.php?code='.urlencode($code));exit;
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();http_response_code(400);die('Không thể đặt hàng: '.h($e->getMessage()));}
