<?php
declare(strict_types=1);
session_start();
$DB_HOST='localhost'; $DB_NAME='fashion_shop'; $DB_USER='root'; $DB_PASS='';
try {
 $pdo=new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",$DB_USER,$DB_PASS,[
  PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
  PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC
 ]);
} catch(PDOException $e) { http_response_code(500); die('Không kết nối được Database. Hãy kiểm tra config.php và import database.sql.'); }
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function money($n): string { return number_format((float)$n,0,',','.').' đ'; }
function cart_count(): int { return array_sum(array_column($_SESSION['cart'] ?? [], 'qty')); }
function require_admin(): void { if(empty($_SESSION['admin_id'])) { header('Location: admin_login.php'); exit; } }
