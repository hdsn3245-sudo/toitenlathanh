CREATE DATABASE IF NOT EXISTS fashion_shop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE fashion_shop;
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS order_items; DROP TABLE IF EXISTS orders; DROP TABLE IF EXISTS products; DROP TABLE IF EXISTS admins;
SET FOREIGN_KEY_CHECKS=1;
CREATE TABLE admins (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(60) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 full_name VARCHAR(120) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE products (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(180) NOT NULL,
 category VARCHAR(80) NOT NULL,
 description TEXT,
 price DECIMAL(12,2) NOT NULL DEFAULT 0,
 stock INT NOT NULL DEFAULT 0,
 image_url VARCHAR(500) DEFAULT NULL,
 is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_category(category), INDEX idx_active(is_active)
) ENGINE=InnoDB;
CREATE TABLE orders (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 order_code VARCHAR(30) NOT NULL UNIQUE,
 customer_name VARCHAR(120) NOT NULL,
 phone VARCHAR(20) NOT NULL,
 email VARCHAR(160) DEFAULT NULL,
 address TEXT NOT NULL,
 note TEXT,
 total DECIMAL(12,2) NOT NULL,
 payment_method ENUM('COD','BANK') NOT NULL DEFAULT 'COD',
 status ENUM('pending','confirmed','shipping','completed','cancelled') NOT NULL DEFAULT 'pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_phone(phone), INDEX idx_created(created_at)
) ENGINE=InnoDB;
CREATE TABLE order_items (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 order_id BIGINT NOT NULL,
 product_id INT NOT NULL,
 product_name VARCHAR(180) NOT NULL,
 unit_price DECIMAL(12,2) NOT NULL,
 quantity INT NOT NULL,
 size VARCHAR(30) NOT NULL,
 color VARCHAR(40) NOT NULL,
 CONSTRAINT fk_item_order FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE,
 CONSTRAINT fk_item_product FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
-- Tài khoản demo: admin / Admin@12345
INSERT INTO admins(username,password_hash,full_name) VALUES
('admin','$2y$12$/a2Bypwe9vOyJUKIUebnKON8Zj91ja2q0HTy4.Xa9IEJmzCmthbtq','Quản trị viên');
INSERT INTO products(name,category,description,price,stock,image_url) VALUES
('Áo thun basic cotton','Áo','Áo thun cotton mềm mại, phom dáng cơ bản, dễ phối đồ.',189000,35,NULL),
('Áo sơ mi linen','Áo','Chất liệu linen thoáng mát, phù hợp đi làm và đi chơi.',329000,18,NULL),
('Quần jeans ống suông','Quần','Thiết kế ống suông hiện đại, chất denim co giãn nhẹ.',459000,22,NULL),
('Váy midi thanh lịch','Váy','Váy midi dáng chữ A, phù hợp nhiều dịp.',399000,15,NULL),
('Áo khoác cardigan','Áo khoác','Cardigan len mỏng, phong cách tối giản.',359000,12,NULL),
('Quần short kaki','Quần','Quần short kaki trẻ trung, dễ vận động.',249000,20,NULL),
('Chân váy chữ A','Váy','Chân váy chữ A cạp cao, dễ kết hợp áo.',289000,17,NULL),
('Áo polo everyday','Áo','Áo polo lịch sự, chất vải thoáng khí.',269000,25,NULL);
