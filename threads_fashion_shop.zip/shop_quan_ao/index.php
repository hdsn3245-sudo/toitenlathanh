<?php
require_once __DIR__.'/config.php';
$cats = $pdo->query("SELECT DISTINCT category FROM products WHERE is_active=1 ORDER BY category")->fetchAll(PDO::FETCH_COLUMN);
$q = trim($_GET['q'] ?? '');
$cat = trim($_GET['category'] ?? '');
$sql = "SELECT * FROM products WHERE is_active=1";
$params = [];
if ($q !== '') { $sql .= " AND (name LIKE ? OR description LIKE ?)"; $params[]="%$q%"; $params[]="%$q%"; }
if ($cat !== '') { $sql .= " AND category=?"; $params[]=$cat; }
$sql .= " ORDER BY created_at DESC";
$stmt=$pdo->prepare($sql); $stmt->execute($params); $products=$stmt->fetchAll();
$count=array_sum(array_column($_SESSION['cart'] ?? [], 'qty'));
include __DIR__.'/header.php';
?>
<section class="hero"><div><span class="eyebrow">BỘ SƯU TẬP MỚI</span><h1>Mặc đẹp mỗi ngày.<br><em>Tự tin theo cách của bạn.</em></h1><p>Khám phá những thiết kế dễ mặc, hiện đại và thoải mái.</p><a class="btn" href="#products">Mua sắm ngay</a></div><div class="hero-art"><div class="circle"></div><div class="hero-label">NEW<br>ARRIVALS</div></div></section>
<section id="products" class="section">
<div class="section-head"><div><span class="eyebrow">DÀNH CHO BẠN</span><h2>Sản phẩm nổi bật</h2></div>
<form class="filters" method="get"><input name="q" placeholder="Tìm sản phẩm..." value="<?=h($q)?>"><select name="category"><option value="">Tất cả danh mục</option><?php foreach($cats as $c): ?><option value="<?=h($c)?>" <?=$cat===$c?'selected':''?>><?=h($c)?></option><?php endforeach ?></select><button class="btn small">Tìm</button></form></div>
<div class="product-grid">
<?php foreach($products as $p): ?>
<article class="product-card"><a href="product.php?id=<?=$p['id']?>" class="product-image"><?php if($p['image_url']): ?><img src="<?=h($p['image_url'])?>" alt="<?=h($p['name'])?>"><?php else: ?><div class="placeholder">THREAD<br><b><?=h(mb_strtoupper(mb_substr($p['name'],0,1)))?></b></div><?php endif ?></a><div class="product-info"><small><?=h($p['category'])?></small><a class="product-name" href="product.php?id=<?=$p['id']?>"><?=h($p['name'])?></a><strong><?=money($p['price'])?></strong><span class="muted">Còn <?= (int)$p['stock']?> sản phẩm</span></div></article>
<?php endforeach ?>
<?php if(!$products): ?><p>Không tìm thấy sản phẩm phù hợp.</p><?php endif ?>
</div></section>
<?php include __DIR__.'/footer.php'; ?>